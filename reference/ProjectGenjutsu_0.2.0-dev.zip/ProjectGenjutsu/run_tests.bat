@echo off
cd /d "%~dp0"
python -m pip install pillow
python -m unittest discover -s tests -t .
pause
