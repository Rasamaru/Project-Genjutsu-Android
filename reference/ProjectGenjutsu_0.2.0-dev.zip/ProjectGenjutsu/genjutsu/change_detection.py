"""Обнаружение изменений кадра по миниатюре и сравнение областей с текстом."""
from PIL import Image, ImageChops, ImageStat

THUMB_SIZE = (160, 90)


def mean_diff(a, b):
    return ImageStat.Stat(ImageChops.difference(a, b)).mean[0]


class ChangeDetector:
    def __init__(self, threshold=0.8):
        self.threshold = threshold
        self.last = None

    @staticmethod
    def make_thumb(image):
        return image.resize(THUMB_SIZE).convert("L")

    def changed(self, thumb):
        return self.last is None or mean_diff(self.last, thumb) >= self.threshold

    def commit(self, thumb):
        self.last = thumb

    def reset(self):
        self.last = None


def crops_same(img_a, img_b, boxes, threshold=6.0):
    """Совпадают ли области с текстом на двух кадрах (грубо, по яркости)."""
    for x1, y1, x2, y2 in boxes:
        box = (max(0, x1), max(0, y1), min(img_a.width, x2), min(img_a.height, y2))
        if box[2] <= box[0] or box[3] <= box[1]:
            continue
        a = img_a.crop(box).convert("L").resize((32, 16), Image.BILINEAR)
        b = img_b.crop(box).convert("L").resize((32, 16), Image.BILINEAR)
        if mean_diff(a, b) >= threshold:
            return False
    return True
