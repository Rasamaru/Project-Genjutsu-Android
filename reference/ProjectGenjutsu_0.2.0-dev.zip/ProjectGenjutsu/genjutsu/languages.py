"""Языки: названия для меню и коды для движков."""

# Название в меню -> тег языка Windows OCR
OCR_LANGS = {
    "Английский": "en-US",
    "Японский": "ja",
    "Китайский (упрощённый)": "zh-Hans-CN",
    "Китайский (традиционный)": "zh-Hant-TW",
    "Корейский": "ko",
    "Русский": "ru",
    "Немецкий": "de",
    "Французский": "fr",
    "Испанский": "es",
}
CJK = {"ja", "ko", "zh-Hans-CN", "zh-Hant-TW"}

# Название в меню -> (код языка, английское название для нейросетей)
TARGETS = {
    "Русский": ("ru", "Russian"),
    "Английский": ("en", "English"),
    "Украинский": ("uk", "Ukrainian"),
}


def target_name(code):
    for _, (c, name) in TARGETS.items():
        if c == code:
            return name
    return code
