"""Конвейер: захват, обнаружение изменений, OCR, группировка, перевод, проверка актуальности.

Не зависит от Qt и Windows: захват, OCR и переводчик подставляются снаружи,
поэтому всю логику можно проверять тестами.
"""
import threading
import time
from dataclasses import dataclass, field
from difflib import SequenceMatcher
from typing import Optional

from ..change_detection import ChangeDetector, crops_same
from ..languages import CJK
from ..text_processing.grouping import block_signature, group_lines


@dataclass
class PipelineRequest:
    region: Optional[tuple]
    force: bool
    ocr_lang: str
    lang: object            # LangPair
    dpr: float = 1.0


@dataclass
class PipelineResult:
    items: Optional[list]   # None: ничего не менять; []: убрать перевод
    skipped: str = ""
    retry_soon: bool = False
    timings: dict = field(default_factory=dict)


def similar(a_texts, b_texts, threshold=0.9):
    a, b = "\n".join(a_texts), "\n".join(b_texts)
    return SequenceMatcher(None, a, b).ratio() >= threshold


class Pipeline:
    def __init__(self, capture, ocr, translator, detector=None, verify_after_s=0.4,
                 clock=time.monotonic, glossary_version=lambda: ""):
        self.capture = capture
        self.ocr = ocr
        self.translator = translator
        self.detector = detector or ChangeDetector()
        self.verify_after_s = verify_after_s
        self.clock = clock
        self.glossary_version = glossary_version
        self._last_sig = None
        self._lock = threading.Lock()

    def reset(self):
        """Забыть предыдущий результат (смена языка, области, движка, очистка оверлея)."""
        with self._lock:
            self._last_sig = None
            self.detector.reset()

    def _commit(self, ctx, thumb, sig):
        with self._lock:
            if ctx.cancelled:
                return
            self.detector.commit(thumb)
            if sig is not None:
                self._last_sig = sig

    def run(self, req, ctx):
        timings = {}
        t_start = self.clock()
        frame = self.capture.grab(req.region, req.dpr)
        grabbed_at = self.clock()
        timings["capture_ms"] = int((grabbed_at - t_start) * 1000)
        ctx.check()

        thumb = self.detector.make_thumb(frame.image)
        if not req.force and not self.detector.changed(thumb):
            return PipelineResult(None, "unchanged", timings=timings)

        t = self.clock()
        lines = self.ocr.recognize(frame.image, req.ocr_lang)
        timings["ocr_ms"] = int((self.clock() - t) * 1000)
        ctx.check()

        blocks = group_lines(lines, cjk=req.ocr_lang in CJK)
        sig = block_signature(blocks)
        with self._lock:
            last_sig = self._last_sig
        if not req.force and sig == last_sig:
            self._commit(ctx, thumb, None)
            return PipelineResult(None, "same_text", timings=timings)

        texts = [b.text for b in blocks]
        translated = []
        if texts:
            t = self.clock()
            translated = self.translator.translate(texts, req.lang, ctx, self.glossary_version())
            timings["translate_ms"] = int((self.clock() - t) * 1000)
        ctx.check()

        # Пока шёл перевод, экран мог измениться: старый перевод показывать нельзя.
        if blocks and self.clock() - grabbed_at >= self.verify_after_s:
            if not self._still_fresh(req, frame, blocks, texts, ctx):
                timings["total_ms"] = int((self.clock() - t_start) * 1000)
                return PipelineResult(None, "screen_changed", retry_soon=True, timings=timings)

        items = self._build_items(blocks, translated, frame, req.dpr)
        self._commit(ctx, thumb, sig)
        timings["total_ms"] = int((self.clock() - t_start) * 1000)
        return PipelineResult(items, timings=timings)

    def _still_fresh(self, req, frame, blocks, texts, ctx):
        frame2 = self.capture.grab(req.region, req.dpr)
        ctx.check()
        boxes = [(b.x1, b.y1, b.x2, b.y2) for b in blocks]
        if crops_same(frame.image, frame2.image, boxes):
            return True
        lines2 = self.ocr.recognize(frame2.image, req.ocr_lang)
        ctx.check()
        texts2 = [b.text for b in group_lines(lines2, cjk=req.ocr_lang in CJK)]
        return similar(texts, texts2)

    @staticmethod
    def _build_items(blocks, translated, frame, dpr):
        items = []
        for b, tr in zip(blocks, translated):
            if tr.strip() == b.text.strip():
                continue
            items.append((int((b.x1 + frame.offset_x) / dpr), int((b.y1 + frame.offset_y) / dpr),
                          int((b.x2 + frame.offset_x) / dpr), int((b.y2 + frame.offset_y) / dpr),
                          tr))
        return items
