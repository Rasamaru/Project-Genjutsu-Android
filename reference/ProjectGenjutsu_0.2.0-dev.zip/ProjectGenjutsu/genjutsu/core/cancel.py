"""Простой протокол отмены: объект с булевым свойством cancelled."""


class Cancelled(Exception):
    """Задача устарела или отменена, результат нужно отбросить."""


class NoCancel:
    cancelled = False


NO_CANCEL = NoCancel()


def check(cancel):
    if cancel is not None and cancel.cancelled:
        raise Cancelled()
