"""Несекретные настройки. Ключи API сюда никогда не записываются."""
import json
import os
from dataclasses import dataclass, fields, asdict


def default_settings_path():
    base = os.environ.get("APPDATA") or os.path.expanduser("~")
    return os.path.join(base, "ProjectGenjutsu", "settings.json")


@dataclass
class Settings:
    ocr_lang: str = "en-US"
    target_code: str = "ru"
    engine: str = "gemini"
    fallback_engine: str = ""
    auto_switch: bool = True
    allow_experimental: bool = False
    timeout_s: float = 10.0
    retries: int = 2
    auto_interval_ms: int = 2000
    verify_after_s: float = 0.4
    region: tuple = None  # (x, y, w, h) в логических координатах или None

    @classmethod
    def load(cls, path=None):
        path = path or default_settings_path()
        s = cls()
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except (OSError, ValueError):
            return s
        if not isinstance(data, dict):
            return s
        for fld in fields(cls):
            if fld.name not in data:
                continue
            value = data[fld.name]
            default = getattr(s, fld.name)
            if fld.name == "region":
                if (isinstance(value, (list, tuple)) and len(value) == 4
                        and all(isinstance(v, int) and not isinstance(v, bool) for v in value)):
                    s.region = tuple(value)
                continue
            if isinstance(default, bool):
                ok = isinstance(value, bool)
            elif isinstance(default, int):
                ok = isinstance(value, int) and not isinstance(value, bool)
            elif isinstance(default, float):
                ok = isinstance(value, (int, float)) and not isinstance(value, bool)
                value = float(value) if ok else value
            else:
                ok = isinstance(value, type(default))
            if ok:
                setattr(s, fld.name, value)
        s.timeout_s = min(max(s.timeout_s, 2.0), 60.0)
        s.retries = min(max(s.retries, 0), 5)
        s.auto_interval_ms = min(max(s.auto_interval_ms, 500), 30000)
        s.verify_after_s = min(max(s.verify_after_s, 0.0), 10.0)
        return s

    def save(self, path=None):
        path = path or default_settings_path()
        try:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            tmp = path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(asdict(self), f, ensure_ascii=False, indent=2)
            os.replace(tmp, path)
            return True
        except OSError:
            return False
