"""Запуск задач по правилу «побеждает последняя».

Зачем: перевод не должен копить неограниченную очередь, зависший сетевой
запрос не должен задерживать новую задачу, а результат устаревшей задачи
не должен показываться на экране.

Потоков одновременно не больше max_threads (по умолчанию 2: текущая задача
и одна устаревшая, дожидающаяся тайм-аута). Лишние задачи ждут в единственном
слоте, куда новая задача всегда заменяет прежнюю.
"""
import threading

from .cancel import Cancelled


class JobContext:
    def __init__(self, worker, generation):
        self._worker = worker
        self._generation = generation

    @property
    def cancelled(self):
        return self._worker._stopped or self._worker._generation != self._generation

    def check(self):
        if self.cancelled:
            raise Cancelled()


class LatestJobWorker:
    def __init__(self, on_result, on_error, on_busy=None, max_threads=2, name="genjutsu-job"):
        self._on_result = on_result
        self._on_error = on_error
        self._on_busy = on_busy or (lambda busy: None)
        self.max_threads = max_threads
        self._name = name
        self._cond = threading.Condition()
        self._generation = 0
        self._pending = None        # (generation, fn)
        self._active = 0
        self._busy_reported = False
        self._stopped = False
        self._threads = []

    # ---- публичный интерфейс
    def submit(self, fn, preempt=True):
        """preempt=True делает текущую задачу устаревшей и запускает новую.

        preempt=False (автоматический режим) ничего не прерывает: если уже
        что-то выполняется или ждёт, задача отбрасывается. Возвращает True,
        если задача принята.
        """
        with self._cond:
            if self._stopped:
                return False
            if not preempt and (self._active > 0 or self._pending is not None):
                return False
            self._generation += 1
            self._pending = (self._generation, fn)
            self._dispatch_locked()
            change = self._busy_change_locked()
        if change is not None:
            self._safe(self._on_busy, change)
        return True

    def cancel(self):
        """Делает идущие и ожидающую задачи устаревшими."""
        with self._cond:
            self._generation += 1
            self._pending = None
            change = self._busy_change_locked()
        if change is not None:
            self._safe(self._on_busy, change)

    @property
    def busy(self):
        with self._cond:
            return self._active > 0 or self._pending is not None

    def stop(self, timeout=2.0):
        with self._cond:
            self._stopped = True
            self._pending = None
            threads = list(self._threads)
        deadline_each = max(timeout / max(len(threads), 1), 0.05)
        for t in threads:
            if t is not threading.current_thread():
                t.join(deadline_each)

    # ---- внутреннее
    def _dispatch_locked(self):
        self._threads = [t for t in self._threads if t.is_alive()]
        while self._pending is not None and self._active < self.max_threads and not self._stopped:
            generation, fn = self._pending
            self._pending = None
            self._active += 1
            t = threading.Thread(target=self._run, args=(generation, fn),
                                 name=self._name, daemon=True)
            self._threads.append(t)
            t.start()

    def _busy_change_locked(self):
        busy = self._active > 0 or self._pending is not None
        if busy != self._busy_reported:
            self._busy_reported = busy
            return busy
        return None

    def _run(self, generation, fn):
        ctx = JobContext(self, generation)
        try:
            result = fn(ctx)
            if not ctx.cancelled:
                self._safe(self._on_result, result)
        except Cancelled:
            pass
        except Exception as exc:  # noqa: BLE001
            if not ctx.cancelled:
                self._safe(self._on_error, exc)
        finally:
            with self._cond:
                self._active -= 1
                self._dispatch_locked()
                change = self._busy_change_locked()
            if change is not None:
                self._safe(self._on_busy, change)

    @staticmethod
    def _safe(callback, arg):
        try:
            callback(arg)
        except Exception:  # noqa: BLE001
            pass
