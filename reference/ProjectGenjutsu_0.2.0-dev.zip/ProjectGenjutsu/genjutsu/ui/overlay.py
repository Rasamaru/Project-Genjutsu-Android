"""Прозрачное окно с переводом поверх экрана."""
from PySide6.QtCore import Qt, QRect
from PySide6.QtGui import QPainter, QColor, QFont, QFontMetrics
from PySide6.QtWidgets import QApplication, QWidget

from ..platform_win import exclude_from_capture


class Overlay(QWidget):
    """Прозрачное окно на весь экран, пропускающее клики, рисует перевод."""

    def __init__(self):
        flags = (Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint
                 | Qt.Tool | Qt.WindowTransparentForInput)
        super().__init__(None, flags)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_ShowWithoutActivating)
        self.setGeometry(QApplication.primaryScreen().geometry())
        self.items = []

    def show_items(self, items):
        self.items = items
        self.show()
        exclude_from_capture(self)
        self.update()

    def clear(self):
        self.items = []
        self.hide()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setRenderHint(QPainter.TextAntialiasing)
        for x1, y1, x2, y2, text in self.items:
            rect = QRect(x1 - 4, y1 - 2, (x2 - x1) + 8, (y2 - y1) + 4)
            font = QFont("Segoe UI")
            flags = Qt.AlignLeft | Qt.AlignVCenter | Qt.TextWordWrap
            size = min(36, max(rect.height(), 9))
            while True:
                font.setPixelSize(size)
                br = QFontMetrics(font).boundingRect(0, 0, rect.width() - 10, 10000,
                                                     Qt.TextWordWrap, text)
                if br.height() <= rect.height() - 4 or size <= 9:
                    break
                size -= 1
            if br.height() > rect.height() - 4:
                rect.setHeight(br.height() + 8)
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(15, 15, 20, 230))
            p.drawRoundedRect(rect, 4, 4)
            p.setPen(QColor(255, 255, 255))
            p.setFont(font)
            p.drawText(rect.adjusted(5, 0, -5, 0), flags, text)
