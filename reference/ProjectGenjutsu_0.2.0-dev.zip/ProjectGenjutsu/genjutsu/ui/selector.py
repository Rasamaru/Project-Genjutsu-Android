"""Выбор области экрана мышью."""
from PySide6.QtCore import Qt, QRect, Signal
from PySide6.QtGui import QPainter, QColor, QPen
from PySide6.QtWidgets import QApplication, QWidget


class RegionSelector(QWidget):
    selected = Signal(QRect)

    def __init__(self):
        flags = Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool
        super().__init__(None, flags)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setCursor(Qt.CrossCursor)
        self.a = None
        self.b = None

    def start(self):
        self.setGeometry(QApplication.primaryScreen().geometry())
        self.a = self.b = None
        self.show()
        self.raise_()
        self.activateWindow()
        self.setFocus()

    def paintEvent(self, _):
        p = QPainter(self)
        p.fillRect(self.rect(), QColor(0, 0, 0, 70))
        if self.a is not None:
            r = QRect(self.a, self.b).normalized()
            p.fillRect(r, QColor(255, 255, 255, 40))
            p.setPen(QPen(QColor(60, 160, 255), 2))
            p.drawRect(r)

    def mousePressEvent(self, e):
        self.a = self.b = e.position().toPoint()
        self.update()

    def mouseMoveEvent(self, e):
        if self.a is not None:
            self.b = e.position().toPoint()
            self.update()

    def mouseReleaseEvent(self, e):
        if self.a is None:
            return
        r = QRect(self.a, e.position().toPoint()).normalized()
        self.hide()
        if r.width() > 20 and r.height() > 10:
            self.selected.emit(r)

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Escape:
            self.hide()
