"""Контроллер приложения: связывает интерфейс, конвейер и переводчики."""
import os
import sys
import time

from PySide6.QtCore import QObject, QPoint, QRect, QTimer, Signal
from PySide6.QtGui import QAction, QActionGroup
from PySide6.QtWidgets import QApplication, QMenu, QToolTip

from .capture.screen import ScreenCapture
from .core.jobs import LatestJobWorker
from .core.pipeline import Pipeline, PipelineRequest
from .core.settings import Settings
from .languages import OCR_LANGS, TARGETS, target_name
from .ocr.winocr_engine import WinOcrEngine
from .translation.base import LangPair
from .translation.errors import TranslationError
from .translation.factory import apply_settings, build_manager
from .ui.float_button import FloatButton
from .ui.overlay import Overlay
from .ui.selector import RegionSelector
from .platform_win import exclude_from_capture

DEBUG = os.environ.get("GENJUTSU_DEBUG") == "1"


class App(QObject):
    result = Signal(object)
    error = Signal(str)
    busy = Signal(bool)
    hotkey = Signal(str)

    def __init__(self, settings_path=None):
        super().__init__()
        self.settings_path = settings_path
        self.settings = Settings.load(settings_path)
        self.manager = build_manager(self.settings)
        self.pipeline = Pipeline(ScreenCapture(), WinOcrEngine(), self.manager,
                                 verify_after_s=self.settings.verify_after_s)
        self.auto = False
        self._last_msg = ("", 0.0)

        self.worker = LatestJobWorker(on_result=self.result.emit,
                                      on_error=self._on_worker_error,
                                      on_busy=self.busy.emit)
        self.overlay = Overlay()
        self.selector = RegionSelector()
        self.button = FloatButton()

        self.result.connect(self.on_result)
        self.error.connect(self.on_error)
        self.busy.connect(self.button.set_busy)
        self.hotkey.connect(self.on_hotkey)
        self.button.double_clicked.connect(self.on_double)
        self.button.menu_requested.connect(self.show_menu)
        self.selector.selected.connect(self.on_region)

        self.timer = QTimer(self)
        self.timer.setInterval(self.settings.auto_interval_ms)
        self.timer.timeout.connect(lambda: self.translate(force=False))

        self.button.show()
        exclude_from_capture(self.button)
        self.register_hotkeys()
        QApplication.instance().aboutToQuit.connect(self.shutdown)

    # ---- жизненный цикл
    def shutdown(self):
        self.timer.stop()
        self.worker.stop(timeout=2.0)
        try:
            import keyboard
            keyboard.unhook_all()
        except Exception:
            pass

    def register_hotkeys(self):
        try:
            import keyboard
            combos = {"ctrl+alt+t": "translate", "ctrl+alt+c": "clear",
                      "ctrl+alt+a": "auto", "ctrl+alt+r": "region"}
            for combo, name in combos.items():
                keyboard.add_hotkey(combo, lambda n=name: self.hotkey.emit(n))
        except Exception as e:
            print("Горячие клавиши отключены:", e)

    def on_hotkey(self, name):
        actions = {
            "translate": lambda: self.translate(True),
            "clear": self.clear_overlay,
            "auto": lambda: self.set_auto(not self.auto),
            "region": self.pick_region,
        }
        actions[name]()

    # ---- действия
    def on_double(self):
        if self.overlay.isVisible() and not self.auto:
            self.clear_overlay()
        else:
            self.translate(True)

    def clear_overlay(self):
        self.overlay.clear()
        self.pipeline.reset()

    def set_auto(self, on):
        self.auto = on
        if on:
            self.pipeline.reset()
            self.timer.start()
            self.translate(True)
        else:
            self.timer.stop()

    def pick_region(self):
        self.overlay.clear()
        self.selector.start()

    def on_region(self, rect):
        self.settings.region = (rect.x(), rect.y(), rect.width(), rect.height())
        self.settings.save(self.settings_path)
        self.worker.cancel()
        self.pipeline.reset()
        QTimer.singleShot(200, lambda: self.translate(True))

    def reset_region(self):
        self.settings.region = None
        self.settings.save(self.settings_path)
        self.worker.cancel()
        self.pipeline.reset()

    def translate(self, force=True):
        """Ручной запуск вытесняет текущую задачу, автоматический её не прерывает."""
        dpr = QApplication.primaryScreen().devicePixelRatio()
        req = PipelineRequest(
            region=self.settings.region, force=force, ocr_lang=self.settings.ocr_lang,
            lang=LangPair(self.settings.ocr_lang, self.settings.target_code,
                          target_name(self.settings.target_code)),
            dpr=dpr)
        self.worker.submit(lambda ctx: self.pipeline.run(req, ctx), preempt=force)

    # ---- результаты (главный поток)
    def _on_worker_error(self, exc):
        if isinstance(exc, TranslationError):
            msg = exc.user_message
        else:
            msg = f"Ошибка: {type(exc).__name__}: {exc}"
        self.error.emit(msg)

    def on_result(self, res):
        if DEBUG:
            print("[genjutsu]", res.skipped or "ok", res.timings)
        if res.items is None:
            if res.retry_soon and self.auto:
                QTimer.singleShot(200, lambda: self.translate(False))
            return
        if res.items:
            self.overlay.show_items(res.items)
        else:
            self.overlay.clear()

    def on_error(self, msg):
        print(msg)
        now = time.monotonic()
        if msg == self._last_msg[0] and now - self._last_msg[1] < 5:
            return
        self._last_msg = (msg, now)
        QToolTip.showText(self.button.mapToGlobal(QPoint(-250, -40)), msg[:300], self.button)

    # ---- меню
    def show_menu(self, pos):
        m = QMenu()
        self._act(m, "Перевести экран", lambda: self.translate(True))
        self._act(m, "Выбрать область...", self.pick_region)
        if self.settings.region:
            self._act(m, "Сбросить область (весь экран)", self.reset_region)
        self._act(m, "Автоперевод", self.set_auto, checked=self.auto)
        self._act(m, "Убрать перевод", self.clear_overlay)
        m.addSeparator()
        self._radio(m.addMenu("Язык оригинала"), OCR_LANGS, self.settings.ocr_lang, self._set_ocr)
        self._radio(m.addMenu("Перевод на"),
                    {n: c for n, (c, _) in TARGETS.items()}, self.settings.target_code,
                    self._set_target)
        engines = {p.title: p.id for p in self.manager.visible_providers()}
        self._radio(m.addMenu("Движок"), engines, self.settings.engine, self._set_engine)
        fallback = {"Нет": ""}
        fallback.update(engines)
        self._radio(m.addMenu("Резервный движок"), fallback, self.settings.fallback_engine,
                    self._set_fallback)
        self._act(m, "Автопереключение на резервный", self._set_auto_switch,
                  checked=self.settings.auto_switch)
        self._act(m, "Экспериментальные (неофициальные) движки", self._set_experimental,
                  checked=self.settings.allow_experimental)
        m.addSeparator()
        self._act(m, "Выход", QApplication.quit)
        m.exec(pos)

    @staticmethod
    def _act(menu, text, fn, checked=None):
        a = QAction(text, menu)
        if checked is not None:
            a.setCheckable(True)
            a.setChecked(checked)
            a.toggled.connect(fn)
        else:
            a.triggered.connect(lambda _=False: fn())
        menu.addAction(a)

    @staticmethod
    def _radio(menu, options, current, setter):
        group = QActionGroup(menu)
        group.setExclusive(True)
        for name, value in options.items():
            a = QAction(name, menu)
            a.setCheckable(True)
            a.setChecked(value == current)
            a.triggered.connect(lambda _=False, v=value: setter(v))
            group.addAction(a)
            menu.addAction(a)

    # ---- изменение настроек
    def _changed(self):
        apply_settings(self.manager, self.settings)
        self.manager.reset_cooldowns()
        self.settings.save(self.settings_path)
        self.worker.cancel()
        self.pipeline.reset()

    def _set_ocr(self, v):
        self.settings.ocr_lang = v
        self._changed()

    def _set_target(self, v):
        self.settings.target_code = v
        self._changed()

    def _set_engine(self, v):
        self.settings.engine = v
        self._changed()

    def _set_fallback(self, v):
        self.settings.fallback_engine = v
        self._changed()

    def _set_auto_switch(self, v):
        self.settings.auto_switch = v
        self._changed()

    def _set_experimental(self, v):
        self.settings.allow_experimental = v
        if not v:
            visible = {p.id for p in self.manager.providers.values() if not p.experimental}
            if self.settings.engine not in visible:
                self.settings.engine = "gemini"
            if self.settings.fallback_engine not in visible:
                self.settings.fallback_engine = ""
        self._changed()


def main():
    qt_app = QApplication(sys.argv)
    qt_app.setQuitOnLastWindowClosed(False)
    controller = App()  # noqa: F841 (объект должен жить до выхода)
    sys.exit(qt_app.exec())
