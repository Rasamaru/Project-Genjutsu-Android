"""Склейка строк OCR в абзацы, чтобы переводить предложение целиком."""
from dataclasses import dataclass


@dataclass
class TextBlock:
    x1: int
    y1: int
    x2: int
    y2: int
    text: str


def group_lines(lines, cjk=False):
    sep = "" if cjk else " "
    items = sorted(lines, key=lambda r: (r.y1, r.x1))
    blocks = []
    for ln in items:
        h = max(ln.y2 - ln.y1, 1)
        target = None
        for b in blocks:
            gap = ln.y1 - b.y2
            near_left = abs(ln.x1 - b.x1) < h * 2.5
            if -h * 0.3 < gap < h * 0.7 and near_left:
                target = b
                break
        if target is None:
            blocks.append(TextBlock(ln.x1, ln.y1, ln.x2, ln.y2, ln.text))
        else:
            target.x1 = min(target.x1, ln.x1)
            target.y1 = min(target.y1, ln.y1)
            target.x2 = max(target.x2, ln.x2)
            target.y2 = max(target.y2, ln.y2)
            target.text += sep + ln.text
    return [b for b in blocks if any(c.isalpha() for c in b.text)]


def block_signature(blocks):
    """Устойчивая подпись набора блоков: текст и грубая позиция."""
    return tuple((b.text, b.x1 // 16, b.y1 // 16) for b in blocks)
