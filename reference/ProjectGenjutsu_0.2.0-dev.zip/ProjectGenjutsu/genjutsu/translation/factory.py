"""Сборка менеджера переводчиков из настроек."""
import os

from .http import HttpClient
from .manager import TranslationManager
from .providers.claude import ClaudeProvider
from .providers.gemini import GeminiProvider
from .providers.google import GoogleGtxProvider
from .providers.microsoft import MicrosoftEdgeProvider


def build_manager(settings, env=None, http=None):
    env = env if env is not None else os.environ
    http = http or HttpClient(timeout=settings.timeout_s, retries=settings.retries)
    providers = {}
    for p in (GeminiProvider(http, env), ClaudeProvider(http, env),
              MicrosoftEdgeProvider(http), GoogleGtxProvider(http)):
        providers[p.id] = p
    manager = TranslationManager(providers)
    apply_settings(manager, settings)
    return manager


def apply_settings(manager, settings):
    manager.configure(primary=settings.engine, fallback=settings.fallback_engine,
                      auto_switch=settings.auto_switch,
                      allow_experimental=settings.allow_experimental)
    for p in manager.providers.values():
        http = getattr(p, "http", None)
        if http is not None:
            http.timeout = settings.timeout_s
            http.retries = settings.retries
