"""HTTP-клиент: тайм-ауты, ограниченные повторы, экспоненциальная задержка, Retry-After."""
import random
import socket
import time
import urllib.error
import urllib.request
from email.utils import parsedate_to_datetime

from ..core.cancel import check
from .errors import (AuthError, BadResponse, NetworkError, NotFound,
                     RateLimited, ServiceUnavailable)

RETRIABLE_STATUS = {500, 502, 503, 504, 529}


def default_opener(url, data, headers, timeout):
    """Возвращает (status, headers, body). Сетевые сбои превращает в NetworkError."""
    req = urllib.request.Request(url, data=data, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status, dict(resp.headers), resp.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        try:
            body = e.read().decode("utf-8", "replace")
        except Exception:  # noqa: BLE001
            body = ""
        return e.code, dict(e.headers or {}), body
    except (socket.timeout, TimeoutError) as e:
        raise NetworkError(str(e), timeout=True)
    except urllib.error.URLError as e:
        if isinstance(e.reason, (socket.timeout, TimeoutError)):
            raise NetworkError(str(e.reason), timeout=True)
        raise NetworkError(str(e.reason))
    except OSError as e:
        raise NetworkError(str(e))


def parse_retry_after(value):
    if value is None:
        return None
    value = str(value).strip()
    try:
        return max(0.0, float(value))
    except ValueError:
        pass
    try:
        when = parsedate_to_datetime(value)
        return max(0.0, when.timestamp() - time.time())
    except (TypeError, ValueError):
        return None


class HttpClient:
    def __init__(self, timeout=10.0, retries=2, opener=None, sleep=time.sleep,
                 rng=random.random, max_inline_wait=5.0, base_delay=1.0, max_delay=8.0):
        self.timeout = timeout
        self.retries = retries
        self.opener = opener or default_opener
        self.sleep = sleep
        self.rng = rng
        self.max_inline_wait = max_inline_wait
        self.base_delay = base_delay
        self.max_delay = max_delay

    def pause(self, seconds, cancel=None):
        """Ожидание небольшими шагами, чтобы отмена срабатывала быстро."""
        left = seconds
        while left > 0:
            check(cancel)
            step = min(0.1, left)
            self.sleep(step)
            left -= step
        check(cancel)

    def request(self, url, data=None, headers=None, cancel=None):
        attempt = 0
        while True:
            check(cancel)
            try:
                return self._once(url, data, headers or {})
            except RateLimited as e:
                # Долгое ожидание не держим: менеджер поставит провайдера на паузу.
                if e.retry_after is None or e.retry_after > self.max_inline_wait \
                        or attempt >= self.retries:
                    raise
                wait = e.retry_after
            except (ServiceUnavailable, NetworkError) as e:
                if attempt >= self.retries:
                    raise
                wait = min(self.max_delay, self.base_delay * (2 ** attempt))
                wait += wait * 0.25 * self.rng()
                retry_after = getattr(e, "retry_after", None)
                if retry_after is not None:
                    if retry_after > self.max_inline_wait:
                        raise
                    wait = max(wait, retry_after)
            attempt += 1
            self.pause(wait, cancel)

    def _once(self, url, data, headers):
        try:
            status, resp_headers, body = self.opener(url, data, headers, self.timeout)
        except NetworkError:
            raise
        except OSError as e:
            raise NetworkError(str(e), timeout=isinstance(e, (socket.timeout, TimeoutError)))
        low = {str(k).lower(): v for k, v in (resp_headers or {}).items()}
        if 200 <= status < 300:
            return body
        retry_after = parse_retry_after(low.get("retry-after"))
        text = (body or "").lower()
        if status == 429:
            raise RateLimited(f"HTTP {status}", retry_after=retry_after)
        if status in RETRIABLE_STATUS or status == 408:
            raise ServiceUnavailable(f"HTTP {status}", retry_after=retry_after, status=status)
        if status == 404:
            raise NotFound(f"HTTP {status}", status=status)
        if status in (401, 403):
            raise AuthError(f"HTTP {status}", status=status)
        if status == 400 and ("api key" in text or "api_key_invalid" in text):
            raise AuthError("HTTP 400", status=status)
        raise BadResponse(f"HTTP {status}", status=status)
