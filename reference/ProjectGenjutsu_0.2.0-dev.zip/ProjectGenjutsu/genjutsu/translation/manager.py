"""Менеджер переводчиков: основной и резервный движок, паузы, кэш, отмена."""
import time

from ..core.cancel import check
from .cache import TranslationCache
from .errors import (AllProvidersUnavailable, AuthError, BadResponse, NetworkError,
                     NotFound, ProviderUnavailable, RateLimited, ServiceUnavailable,
                     TranslationError)

# Паузы после сбоя провайдера (секунды), чтобы автоматический режим не бил по сервису
SHORT_PAUSE = 10.0
CONFIG_PAUSE = 30.0
RATE_DEFAULT = 60.0
RATE_MIN, RATE_MAX = 5.0, 300.0


class TranslationManager:
    def __init__(self, providers, cache=None, clock=time.monotonic):
        self.providers = providers
        self.cache = cache if cache is not None else TranslationCache()
        self.clock = clock
        self.primary = ""
        self.fallback = ""
        self.auto_switch = True
        self.allow_experimental = False
        self.last_used = ""
        self.last_error = None
        self._cooldown = {}

    # ---- настройка
    def configure(self, primary=None, fallback=None, auto_switch=None, allow_experimental=None):
        if primary is not None:
            self.primary = primary
        if fallback is not None:
            self.fallback = fallback
        if auto_switch is not None:
            self.auto_switch = auto_switch
        if allow_experimental is not None:
            self.allow_experimental = allow_experimental

    def visible_providers(self):
        """Движки, которые можно показывать в меню."""
        return [p for p in self.providers.values()
                if self.allow_experimental or not p.experimental]

    def reset_cooldowns(self):
        self._cooldown.clear()

    def cooldown_left(self, provider_id):
        return max(0.0, self._cooldown.get(provider_id, 0.0) - self.clock())

    # ---- перевод
    def _candidates(self):
        ids = [self.primary]
        if self.auto_switch and self.fallback and self.fallback != self.primary:
            ids.append(self.fallback)
        allowed = []
        for pid in ids:
            p = self.providers.get(pid)
            if p is None or (p.experimental and not self.allow_experimental):
                continue
            allowed.append(p)
        return allowed

    def translate(self, texts, lang, cancel=None, glossary_version=""):
        result = {}
        unique = []
        for t in dict.fromkeys(texts):
            if not any(c.isalpha() for c in t):
                result[t] = t
            else:
                unique.append(t)
        if unique:
            result.update(self._translate_unique(unique, lang, cancel, glossary_version))
        return [result[t] for t in texts]

    def _translate_unique(self, unique, lang, cancel, glossary_version):
        allowed = self._candidates()
        if not allowed:
            raise ProviderUnavailable("выбранный движок отключён или не найден")
        ready = [p for p in allowed if self.cooldown_left(p.id) <= 0]
        if not ready:
            raise AllProvidersUnavailable(wait_s=min(self.cooldown_left(p.id) for p in allowed))

        found = {}
        remaining = list(unique)
        last_error = None
        for provider in ready:
            check(cancel)
            for t in list(remaining):
                key = TranslationCache.key(provider.id, lang.source, lang.target_code,
                                           glossary_version, t)
                hit = self.cache.get(key)
                if hit is not None:
                    found[t] = hit
                    remaining.remove(t)
            if not remaining:
                self.last_used = provider.id
                break
            try:
                out = provider.translate(remaining, lang, cancel)
                if len(out) != len(remaining):
                    raise BadResponse("неверное число переводов в ответе")
            except TranslationError as e:
                last_error = e
                self._penalize(provider.id, e)
                continue
            # Результат хранится под тем провайдером, который его выдал.
            for src, dst in zip(remaining, out):
                self.cache.put(TranslationCache.key(provider.id, lang.source, lang.target_code,
                                                    glossary_version, src), dst)
                found[src] = dst
            self.last_used = provider.id
            remaining = []
            break
        if remaining:
            self.last_error = last_error
            raise last_error if last_error else AllProvidersUnavailable()
        self.last_error = None
        return found

    def _penalize(self, provider_id, error):
        if isinstance(error, RateLimited):
            wait = error.retry_after if error.retry_after else RATE_DEFAULT
            wait = min(max(wait, RATE_MIN), RATE_MAX)
        elif isinstance(error, (AuthError, NotFound, ProviderUnavailable)):
            wait = CONFIG_PAUSE
        elif isinstance(error, (ServiceUnavailable, NetworkError, BadResponse)):
            wait = SHORT_PAUSE
        else:
            wait = SHORT_PAUSE
        self._cooldown[provider_id] = self.clock() + wait
