"""Общий интерфейс провайдера перевода."""
from dataclasses import dataclass


@dataclass(frozen=True)
class LangPair:
    source: str = "auto"
    target_code: str = "ru"
    target_name: str = "Russian"


class Provider:
    id = ""
    title = ""
    experimental = False   # неофициальные точки, по умолчанию выключены
    local = False          # локальный движок: данные не уходят в интернет
    requires_key = False

    def translate(self, texts, lang, cancel=None):
        """Переводит список строк, возвращает список той же длины."""
        raise NotImplementedError
