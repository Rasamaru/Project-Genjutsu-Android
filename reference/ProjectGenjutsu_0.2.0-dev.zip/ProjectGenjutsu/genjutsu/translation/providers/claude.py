"""Claude через официальный SDK. Необязательный платный провайдер."""
import json
import os

from ..base import Provider
from ..errors import (AuthError, BadResponse, NetworkError, NotFound,
                      RateLimited, ServiceUnavailable)
from ..prompts import parse_array, system_prompt

DEFAULT_MODEL = "claude-haiku-5-5"


class ClaudeProvider(Provider):
    id = "claude"
    title = "Claude (платный ключ API)"
    requires_key = True

    def __init__(self, http, env=None, model=None):
        self.http = http
        self.env = env if env is not None else os.environ
        self.model = model

    def translate(self, texts, lang, cancel=None):
        if not self.env.get("ANTHROPIC_API_KEY"):
            raise AuthError("не задана переменная ANTHROPIC_API_KEY")
        try:
            import anthropic
        except ImportError:
            raise NotFound("библиотека anthropic не установлена")
        client = anthropic.Anthropic(timeout=self.http.timeout, max_retries=self.http.retries)
        try:
            msg = client.messages.create(
                model=self.model or self.env.get("CLAUDE_MODEL") or DEFAULT_MODEL,
                max_tokens=4000,
                system=system_prompt(lang.target_name),
                messages=[{"role": "user", "content": json.dumps(texts, ensure_ascii=False)}],
            )
        except anthropic.APITimeoutError:
            raise NetworkError("", timeout=True)
        except anthropic.APIConnectionError:
            raise NetworkError("")
        except anthropic.RateLimitError as e:
            raise RateLimited("HTTP 429", retry_after=_retry_after(e))
        except (anthropic.AuthenticationError, anthropic.PermissionDeniedError):
            raise AuthError("")
        except anthropic.NotFoundError:
            raise NotFound("модель Claude недоступна")
        except anthropic.APIStatusError as e:
            if getattr(e, "status_code", 0) in (500, 502, 503, 504, 529):
                raise ServiceUnavailable(f"HTTP {e.status_code}", status=e.status_code)
            raise BadResponse(f"HTTP {getattr(e, 'status_code', '?')}")
        try:
            return parse_array(msg.content[0].text, len(texts))
        except (AttributeError, IndexError):
            raise BadResponse("пустой ответ")


def _retry_after(exc):
    try:
        value = exc.response.headers.get("retry-after")
        return float(value) if value is not None else None
    except Exception:  # noqa: BLE001
        return None
