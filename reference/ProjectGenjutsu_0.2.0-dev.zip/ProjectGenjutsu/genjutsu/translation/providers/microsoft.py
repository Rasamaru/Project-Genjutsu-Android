"""ЭКСПЕРИМЕНТАЛЬНО: неофициальный доступ через токен браузера Edge.

Не является публичным API, может перестать работать без предупреждения.
Выключен по умолчанию, включается пользователем явно.
"""
import json
import time

from ..base import Provider
from ..errors import AuthError, BadResponse

TOKEN_URL = "https://edge.microsoft.com/translate/auth"
API_URL = "https://api.cognitive.microsofttranslator.com/translate?api-version=3.0&to="
TOKEN_TTL = 480


class MicrosoftEdgeProvider(Provider):
    id = "microsoft"
    title = "Microsoft (экспериментально, неофициально)"
    experimental = True

    def __init__(self, http, clock=time.monotonic):
        self.http = http
        self.clock = clock
        self._token = None
        self._token_time = 0.0

    def _get_token(self, cancel, force=False):
        if force or not self._token or self.clock() - self._token_time > TOKEN_TTL:
            self._token = self.http.request(TOKEN_URL, None, {}, cancel).strip()
            self._token_time = self.clock()
        return self._token

    def translate(self, texts, lang, cancel=None):
        clean = [" ".join(t.split()) for t in texts]
        body = json.dumps([{"Text": t} for t in clean]).encode("utf-8")
        for attempt in (0, 1):
            headers = {"Authorization": "Bearer " + self._get_token(cancel, force=attempt > 0),
                       "Content-Type": "application/json"}
            try:
                raw = self.http.request(API_URL + lang.target_code, body, headers, cancel)
                break
            except AuthError:
                self._token = None
                if attempt == 1:
                    raise
        try:
            data = json.loads(raw)
            out = [d["translations"][0]["text"] for d in data]
        except (ValueError, KeyError, IndexError, TypeError):
            raise BadResponse("не удалось разобрать ответ")
        if len(out) != len(texts):
            raise BadResponse("неверное число переводов в ответе")
        return out
