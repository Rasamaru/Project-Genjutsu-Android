"""Gemini через официальный REST API (бесплатный ключ из Google AI Studio)."""
import json
import os

from ..base import Provider
from ..errors import AuthError, BadResponse, NotFound
from ..prompts import parse_array, system_prompt

DEFAULT_MODEL = "gemini-3.8-flash"
URL = "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"


class GeminiProvider(Provider):
    id = "gemini"
    title = "Gemini (бесплатный ключ)"
    requires_key = True

    def __init__(self, http, env=None, model=None):
        self.http = http
        self.env = env if env is not None else os.environ
        self.model = model

    def _key(self):
        return self.env.get("GEMINI_API_KEY") or self.env.get("GOOGLE_API_KEY")

    def translate(self, texts, lang, cancel=None):
        key = self._key()
        if not key:
            raise AuthError("не задана переменная GEMINI_API_KEY")
        model = self.model or self.env.get("GEMINI_MODEL") or DEFAULT_MODEL
        payload = {
            "systemInstruction": {"parts": [{"text": system_prompt(lang.target_name)}]},
            "contents": [{"role": "user",
                          "parts": [{"text": json.dumps(texts, ensure_ascii=False)}]}],
            "generationConfig": {"temperature": 0.2, "responseMimeType": "application/json"},
        }
        headers = {"Content-Type": "application/json", "x-goog-api-key": key}
        try:
            body = self.http.request(URL.format(model=model),
                                     json.dumps(payload).encode("utf-8"), headers, cancel)
        except NotFound:
            raise NotFound(f"модель {model} недоступна, задайте другую в GEMINI_MODEL")
        try:
            data = json.loads(body)
            parts = data["candidates"][0]["content"]["parts"]
            text = "".join(p.get("text", "") for p in parts)
        except (ValueError, KeyError, IndexError, TypeError, AttributeError):
            raise BadResponse("пустой ответ (возможно, сработал фильтр)")
        return parse_array(text, len(texts))
