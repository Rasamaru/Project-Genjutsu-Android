"""ЭКСПЕРИМЕНТАЛЬНО: неофициальная бесплатная точка Google (client=gtx).

Не является публичным API, может перестать работать без предупреждения.
Выключен по умолчанию, включается пользователем явно.
"""
import json
import urllib.parse

from ..base import Provider
from ..errors import BadResponse

URL = "https://translate.googleapis.com/translate_a/single"


class GoogleGtxProvider(Provider):
    id = "google"
    title = "Google (экспериментально, неофициально)"
    experimental = True

    def __init__(self, http):
        self.http = http

    def _one(self, text, code, cancel):
        data = urllib.parse.urlencode(
            {"client": "gtx", "sl": "auto", "tl": code, "dt": "t", "q": text}).encode("utf-8")
        raw = self.http.request(URL, data, {"Content-Type": "application/x-www-form-urlencoded"},
                                cancel)
        try:
            parts = json.loads(raw)[0]
            return "".join(seg[0] for seg in parts if seg and seg[0])
        except (ValueError, IndexError, TypeError, KeyError):
            raise BadResponse("не удалось разобрать ответ")

    def translate(self, texts, lang, cancel=None):
        clean = [" ".join(t.split()) for t in texts]
        joined = "\n".join(clean)
        if len(joined) < 4500:
            out = [x.strip() for x in self._one(joined, lang.target_code, cancel).split("\n")]
            if len(out) == len(texts):
                return out
        # Запасной путь: по одному блоку с паузой, не больше десяти за раз.
        res = []
        for t in clean[:10]:
            res.append(self._one(t, lang.target_code, cancel))
            self.http.pause(0.4, cancel)
        return res + clean[10:]
