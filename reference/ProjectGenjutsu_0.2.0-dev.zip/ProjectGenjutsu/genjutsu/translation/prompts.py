import json

from .errors import BadResponse


def system_prompt(target_name):
    return (
        "You translate on-screen text from games and apps into " + target_name + ". "
        "The input is a JSON array of strings. Return ONLY a JSON array of the same "
        "length with the translations in the same order. Keep names, numbers and "
        "placeholders such as %s unchanged. Use natural, concise phrasing suited to "
        "UI and dialogue."
    )


def parse_array(text, expected):
    text = (text or "").strip()
    start, end = text.find("["), text.rfind("]")
    if start < 0 or end < start:
        raise BadResponse("ответ без списка переводов")
    try:
        arr = json.loads(text[start:end + 1])
    except ValueError:
        raise BadResponse("ответ не удалось разобрать")
    if not isinstance(arr, list) or len(arr) != expected:
        raise BadResponse("неверное число переводов в ответе")
    return [str(x) for x in arr]
