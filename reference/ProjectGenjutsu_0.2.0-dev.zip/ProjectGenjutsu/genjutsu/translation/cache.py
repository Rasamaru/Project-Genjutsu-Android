"""Ограниченный потокобезопасный LRU-кэш. Ошибки в него не попадают."""
import threading
from collections import OrderedDict


class TranslationCache:
    def __init__(self, max_items=2000):
        self.max_items = max_items
        self._data = OrderedDict()
        self._lock = threading.Lock()

    @staticmethod
    def key(provider_id, source, target, glossary_version, text):
        return (provider_id, source, target, glossary_version, text)

    def get(self, key):
        with self._lock:
            if key not in self._data:
                return None
            self._data.move_to_end(key)
            return self._data[key]

    def put(self, key, value):
        with self._lock:
            self._data[key] = value
            self._data.move_to_end(key)
            while len(self._data) > self.max_items:
                self._data.popitem(last=False)

    def clear(self):
        with self._lock:
            self._data.clear()

    def __len__(self):
        with self._lock:
            return len(self._data)

    def __contains__(self, key):
        with self._lock:
            return key in self._data
