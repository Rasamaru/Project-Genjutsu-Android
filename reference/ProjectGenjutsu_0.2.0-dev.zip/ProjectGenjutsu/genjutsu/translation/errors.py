"""Ошибки перевода с понятными пользователю сообщениями (по UI Spec, раздел 6)."""


class TranslationError(Exception):
    base_message = "Ошибка перевода"

    def __init__(self, detail="", status=None):
        super().__init__(detail or self.base_message)
        self.detail = detail
        self.status = status

    @property
    def user_message(self):
        return self.base_message + (": " + self.detail if self.detail else "")


class NetworkError(TranslationError):
    base_message = "Нет подключения к облачному провайдеру"

    def __init__(self, detail="", timeout=False):
        super().__init__(detail)
        self.timeout = timeout

    @property
    def user_message(self):
        if self.timeout:
            return "Сервис не ответил вовремя (тайм-аут)"
        return self.base_message


class RateLimited(TranslationError):
    base_message = "Лимит запросов: повторим позже"

    def __init__(self, detail="", retry_after=None, status=429):
        super().__init__(detail, status)
        self.retry_after = retry_after


class ServiceUnavailable(TranslationError):
    base_message = "Сервис временно недоступен"

    def __init__(self, detail="", retry_after=None, status=503):
        super().__init__(detail, status)
        self.retry_after = retry_after


class NotFound(TranslationError):
    base_message = "Модель или адрес сервиса недоступны"


class AuthError(TranslationError):
    base_message = "Ключ не задан или не подходит к этому провайдеру"


class BadResponse(TranslationError):
    base_message = "Сервис вернул неожиданный ответ"


class ProviderUnavailable(TranslationError):
    base_message = "Движок перевода недоступен"


class AllProvidersUnavailable(TranslationError):
    base_message = "Все движки временно недоступны"

    def __init__(self, detail="", wait_s=None):
        super().__init__(detail)
        self.wait_s = wait_s

    @property
    def user_message(self):
        if self.wait_s:
            return f"{self.base_message}, повтор через {int(self.wait_s) + 1} с"
        return self.base_message + (": " + self.detail if self.detail else "")
