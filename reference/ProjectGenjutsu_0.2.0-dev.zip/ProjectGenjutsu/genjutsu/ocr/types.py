from dataclasses import dataclass


@dataclass
class OcrLine:
    """Строка текста и её рамка в пикселях изображения."""
    x1: int
    y1: int
    x2: int
    y2: int
    text: str
