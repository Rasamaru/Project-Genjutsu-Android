"""OCR встроенными средствами Windows (через winocr). Только Windows."""
from ..languages import CJK
from .types import OcrLine


class WinOcrEngine:
    def recognize(self, image, lang):
        import winocr
        res = winocr.recognize_pil_sync(image, lang)
        cjk = lang in CJK
        sep = "" if cjk else " "
        out = []
        for ln in res.get("lines", []):
            words = ln.get("words") or []
            if not words:
                continue
            rects = [w["bounding_rect"] for w in words]
            out.append(OcrLine(
                x1=min(r["x"] for r in rects),
                y1=min(r["y"] for r in rects),
                x2=max(r["x"] + r["width"] for r in rects),
                y2=max(r["y"] + r["height"] for r in rects),
                text=sep.join(w["text"] for w in words),
            ))
        return out
