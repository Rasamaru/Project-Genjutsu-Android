"""Project Genjutsu: экранный переводчик для Windows."""
__version__ = "0.2.0-dev"
