"""Мелкие функции, зависящие от Windows."""
import ctypes


def exclude_from_capture(widget):
    """Окно не попадает в скриншоты (Windows 10 2004 и новее)."""
    try:
        ctypes.windll.user32.SetWindowDisplayAffinity(int(widget.winId()), 0x11)
    except Exception:
        pass
