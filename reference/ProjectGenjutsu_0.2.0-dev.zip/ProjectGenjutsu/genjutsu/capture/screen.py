"""Захват области основного монитора. Только Windows (mss)."""
from dataclasses import dataclass


@dataclass
class Frame:
    image: object          # PIL.Image
    offset_x: int          # смещение кадра от левого верхнего угла монитора, физические пиксели
    offset_y: int


class ScreenCapture:
    def grab(self, region, dpr):
        """region: (x, y, w, h) в логических координатах или None для всего монитора."""
        import mss
        from PIL import Image
        ctor = getattr(mss, "MSS", None) or mss.mss
        with ctor() as sct:
            mon = sct.monitors[1]
            if region:
                x, y, w, h = region
                left = mon["left"] + int(x * dpr)
                top = mon["top"] + int(y * dpr)
                width, height = int(w * dpr), int(h * dpr)
            else:
                left, top = mon["left"], mon["top"]
                width, height = mon["width"], mon["height"]
            shot = sct.grab({"left": left, "top": top, "width": width, "height": height})
            ox, oy = left - mon["left"], top - mon["top"]
        img = Image.frombytes("RGB", shot.size, shot.bgra, "raw", "BGRX")
        return Frame(img, ox, oy)
