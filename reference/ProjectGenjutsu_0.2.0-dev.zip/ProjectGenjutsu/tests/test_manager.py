import unittest

from genjutsu.core.cancel import Cancelled
from genjutsu.translation.base import LangPair, Provider
from genjutsu.translation.cache import TranslationCache
from genjutsu.translation.errors import (AllProvidersUnavailable, AuthError, BadResponse,
                                         ProviderUnavailable, RateLimited, ServiceUnavailable)
from genjutsu.translation.manager import TranslationManager

LANG = LangPair("en-US", "ru", "Russian")


class Fake(Provider):
    def __init__(self, pid, tag=None, error=None, experimental=False):
        self.id = pid
        self.title = pid
        self.tag = tag or pid
        self.error = error
        self.experimental = experimental
        self.calls = []

    def translate(self, texts, lang, cancel=None):
        self.calls.append(list(texts))
        if self.error:
            raise self.error
        return [f"{self.tag}:{t}" for t in texts]


class Clock:
    def __init__(self):
        self.now = 1000.0

    def __call__(self):
        return self.now


def make(*providers, primary=None, fallback="", clock=None, allow_exp=False):
    m = TranslationManager({p.id: p for p in providers}, clock=clock or Clock())
    m.configure(primary=primary or providers[0].id, fallback=fallback,
                auto_switch=True, allow_experimental=allow_exp)
    return m


class ManagerTests(unittest.TestCase):
    def test_translates_and_dedupes(self):
        a = Fake("a")
        m = make(a)
        self.assertEqual(m.translate(["Hi", "Hi", "Bye"], LANG), ["a:Hi", "a:Hi", "a:Bye"])
        self.assertEqual(a.calls, [["Hi", "Bye"]])

    def test_non_text_not_sent(self):
        a = Fake("a")
        m = make(a)
        self.assertEqual(m.translate(["123", "!!"], LANG), ["123", "!!"])
        self.assertEqual(a.calls, [])

    def test_cache_hit_avoids_second_call(self):
        a = Fake("a")
        m = make(a)
        m.translate(["Hi"], LANG)
        m.translate(["Hi", "New"], LANG)
        self.assertEqual(a.calls, [["Hi"], ["New"]])

    def test_cache_key_depends_on_language_and_glossary(self):
        a = Fake("a")
        m = make(a)
        m.translate(["Hi"], LANG)
        m.translate(["Hi"], LangPair("en-US", "uk", "Ukrainian"))
        m.translate(["Hi"], LANG, glossary_version="v2")
        self.assertEqual(len(a.calls), 3)

    def test_failure_is_not_cached(self):
        a = Fake("a", error=ServiceUnavailable())
        m = make(a)
        with self.assertRaises(ServiceUnavailable):
            m.translate(["Hi"], LANG)
        self.assertEqual(len(m.cache), 0)

    def test_fallback_used_and_cached_under_fallback_not_primary(self):
        a = Fake("a", error=ServiceUnavailable())
        b = Fake("b")
        m = make(a, b, fallback="b")
        self.assertEqual(m.translate(["Hi"], LANG), ["b:Hi"])
        self.assertEqual(m.last_used, "b")
        self.assertIn(TranslationCache.key("b", "en-US", "ru", "", "Hi"), m.cache)
        self.assertNotIn(TranslationCache.key("a", "en-US", "ru", "", "Hi"), m.cache)

    def test_primary_returns_after_cooldown_and_gives_own_translation(self):
        clock = Clock()
        a = Fake("a", error=ServiceUnavailable())
        b = Fake("b")
        m = make(a, b, fallback="b", clock=clock)
        m.translate(["Hi"], LANG)
        a.error = None
        clock.now += 11  # короткая пауза после сбоя закончилась
        self.assertEqual(m.translate(["Hi"], LANG), ["a:Hi"])

    def test_rate_limit_puts_provider_on_cooldown(self):
        clock = Clock()
        a = Fake("a", error=RateLimited(retry_after=30))
        m = make(a, clock=clock)
        with self.assertRaises(RateLimited):
            m.translate(["Hi"], LANG)
        with self.assertRaises(AllProvidersUnavailable) as cm:
            m.translate(["Other"], LANG)
        self.assertEqual(len(a.calls), 1)  # сервис больше не дёргали
        self.assertGreater(cm.exception.wait_s, 0)
        clock.now += 31
        a.error = None
        self.assertEqual(m.translate(["Other"], LANG), ["a:Other"])

    def test_rate_limit_without_retry_after_uses_default_pause(self):
        clock = Clock()
        a = Fake("a", error=RateLimited())
        m = make(a, clock=clock)
        with self.assertRaises(RateLimited):
            m.translate(["Hi"], LANG)
        self.assertAlmostEqual(m.cooldown_left("a"), 60.0)

    def test_rate_limited_primary_switches_to_fallback_without_waiting(self):
        a = Fake("a", error=RateLimited(retry_after=120))
        b = Fake("b")
        m = make(a, b, fallback="b")
        self.assertEqual(m.translate(["Hi"], LANG), ["b:Hi"])
        self.assertEqual(m.translate(["Next"], LANG), ["b:Next"])
        self.assertEqual(len(a.calls), 1)

    def test_auto_switch_off_does_not_use_fallback(self):
        a = Fake("a", error=ServiceUnavailable())
        b = Fake("b")
        m = make(a, b, fallback="b")
        m.configure(auto_switch=False)
        with self.assertRaises(ServiceUnavailable):
            m.translate(["Hi"], LANG)
        self.assertEqual(b.calls, [])

    def test_experimental_disabled_by_default(self):
        g = Fake("google", experimental=True)
        m = make(g)
        with self.assertRaises(ProviderUnavailable):
            m.translate(["Hi"], LANG)
        self.assertEqual(g.calls, [])
        self.assertEqual(m.visible_providers(), [])

    def test_experimental_can_be_enabled(self):
        g = Fake("google", experimental=True)
        m = make(g, allow_exp=True)
        self.assertEqual(m.translate(["Hi"], LANG), ["google:Hi"])
        self.assertEqual(m.visible_providers(), [g])

    def test_experimental_fallback_ignored_when_disabled(self):
        a = Fake("a", error=ServiceUnavailable())
        g = Fake("google", experimental=True)
        m = make(a, g, fallback="google")
        with self.assertRaises(ServiceUnavailable):
            m.translate(["Hi"], LANG)
        self.assertEqual(g.calls, [])

    def test_wrong_length_answer_is_error_and_not_cached(self):
        class Bad(Fake):
            def translate(self, texts, lang, cancel=None):
                return ["only one"]
        b = Bad("b")
        m = make(b)
        with self.assertRaises(BadResponse):
            m.translate(["x y", "z w"], LANG)
        self.assertEqual(len(m.cache), 0)

    def test_config_error_pauses_provider(self):
        a = Fake("a", error=AuthError("нет ключа"))
        m = make(a)
        with self.assertRaises(AuthError):
            m.translate(["Hi"], LANG)
        self.assertGreater(m.cooldown_left("a"), 0)

    def test_cancelled_before_call(self):
        class C:
            cancelled = True
        a = Fake("a")
        m = make(a)
        with self.assertRaises(Cancelled):
            m.translate(["Hi"], LANG, cancel=C())
        self.assertEqual(a.calls, [])

    def test_cache_is_bounded(self):
        cache = TranslationCache(max_items=3)
        for i in range(10):
            cache.put(("k", i), str(i))
        self.assertEqual(len(cache), 3)
        self.assertIsNone(cache.get(("k", 0)))
        self.assertEqual(cache.get(("k", 9)), "9")

    def test_cache_lru_order(self):
        cache = TranslationCache(max_items=2)
        cache.put("a", 1)
        cache.put("b", 2)
        cache.get("a")
        cache.put("c", 3)
        self.assertIn("a", cache)
        self.assertNotIn("b", cache)


if __name__ == "__main__":
    unittest.main()
