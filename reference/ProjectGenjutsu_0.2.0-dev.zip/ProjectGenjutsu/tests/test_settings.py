import json
import os
import tempfile
import unittest

from genjutsu.core.settings import Settings


class SettingsTests(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.TemporaryDirectory()
        self.path = os.path.join(self.dir.name, "sub", "settings.json")

    def tearDown(self):
        self.dir.cleanup()

    def test_missing_file_gives_defaults(self):
        s = Settings.load(self.path)
        self.assertEqual((s.engine, s.target_code, s.allow_experimental),
                         ("gemini", "ru", False))

    def test_roundtrip(self):
        s = Settings()
        s.ocr_lang, s.engine, s.region, s.allow_experimental = "ja", "claude", (1, 2, 30, 40), True
        self.assertTrue(s.save(self.path))
        t = Settings.load(self.path)
        self.assertEqual((t.ocr_lang, t.engine, t.region, t.allow_experimental),
                         ("ja", "claude", (1, 2, 30, 40), True))

    def test_corrupt_file_gives_defaults(self):
        os.makedirs(os.path.dirname(self.path))
        with open(self.path, "w", encoding="utf-8") as f:
            f.write("{не json")
        self.assertEqual(Settings.load(self.path).engine, "gemini")

    def test_wrong_types_and_unknown_keys_ignored(self):
        os.makedirs(os.path.dirname(self.path))
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump({"engine": 5, "retries": "много", "allow_experimental": "yes",
                       "region": [1, 2], "mystery": 1}, f)
        s = Settings.load(self.path)
        self.assertEqual((s.engine, s.retries, s.allow_experimental, s.region),
                         ("gemini", 2, False, None))

    def test_values_are_clamped(self):
        os.makedirs(os.path.dirname(self.path))
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump({"timeout_s": 9999, "retries": 99, "auto_interval_ms": 1}, f)
        s = Settings.load(self.path)
        self.assertEqual((s.timeout_s, s.retries, s.auto_interval_ms), (60.0, 5, 500))

    def test_no_secret_fields_are_stored(self):
        Settings().save(self.path)
        with open(self.path, encoding="utf-8") as f:
            text = f.read().lower()
        for word in ("api_key", "apikey", "secret", "token", "password"):
            self.assertNotIn(word, text)


if __name__ == "__main__":
    unittest.main()
