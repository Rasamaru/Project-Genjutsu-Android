import json
import unittest

from genjutsu.core.settings import Settings
from genjutsu.translation.base import LangPair
from genjutsu.translation.errors import (AuthError, BadResponse, NotFound)
from genjutsu.translation.factory import build_manager
from genjutsu.translation.http import HttpClient
from genjutsu.translation.providers.gemini import GeminiProvider
from genjutsu.translation.providers.google import GoogleGtxProvider
from genjutsu.translation.providers.microsoft import MicrosoftEdgeProvider

LANG = LangPair("en-US", "ru", "Russian")


class Net:
    """Фальшивая сеть: отвечает по правилам и запоминает запросы."""

    def __init__(self, handler):
        self.handler = handler
        self.requests = []

    def __call__(self, url, data, headers, timeout):
        self.requests.append((url, data, headers))
        return self.handler(url, data, headers)


def http(handler):
    net = Net(handler)
    return HttpClient(timeout=1, retries=0, opener=net, sleep=lambda s: None), net


def gemini_reply(text):
    return (200, {}, json.dumps({"candidates": [{"content": {"parts": [{"text": text}]}}]}))


class GeminiTests(unittest.TestCase):
    def provider(self, handler, env=None, model=None):
        h, net = http(handler)
        return GeminiProvider(h, env if env is not None else {"GEMINI_API_KEY": "k"}, model), net

    def test_success_and_request_shape(self):
        p, net = self.provider(lambda *a: gemini_reply('["Привет", "Пока"]'))
        self.assertEqual(p.translate(["Hello", "Bye"], LANG), ["Привет", "Пока"])
        url, data, headers = net.requests[0]
        self.assertIn("gemini-3.8-flash:generateContent", url)
        self.assertEqual(headers["x-goog-api-key"], "k")
        self.assertNotIn("k", url.split("?")[-1] if "?" in url else "")  # ключ не в адресе
        body = json.loads(data)
        self.assertEqual(json.loads(body["contents"][0]["parts"][0]["text"]), ["Hello", "Bye"])

    def test_fenced_json_is_accepted(self):
        p, _ = self.provider(lambda *a: gemini_reply('```json\n["Да"]\n```'))
        self.assertEqual(p.translate(["Yes"], LANG), ["Да"])

    def test_missing_key(self):
        p, net = self.provider(lambda *a: gemini_reply("[]"), env={})
        with self.assertRaises(AuthError):
            p.translate(["Hi"], LANG)
        self.assertEqual(net.requests, [])

    def test_model_from_env_and_404_message_names_it(self):
        p, net = self.provider(lambda *a: (404, {}, "gone"),
                               env={"GEMINI_API_KEY": "k", "GEMINI_MODEL": "old-model"})
        with self.assertRaises(NotFound) as cm:
            p.translate(["Hi"], LANG)
        self.assertIn("old-model", net.requests[0][0])
        self.assertIn("old-model", cm.exception.user_message)

    def test_empty_candidates_is_bad_response(self):
        p, _ = self.provider(lambda *a: (200, {}, json.dumps({"candidates": []})))
        with self.assertRaises(BadResponse):
            p.translate(["Hi"], LANG)

    def test_wrong_count_is_bad_response(self):
        p, _ = self.provider(lambda *a: gemini_reply('["один"]'))
        with self.assertRaises(BadResponse):
            p.translate(["a b", "c d"], LANG)

    def test_garbage_is_bad_response(self):
        p, _ = self.provider(lambda *a: (200, {}, "<html>oops</html>"))
        with self.assertRaises(BadResponse):
            p.translate(["Hi"], LANG)


class MicrosoftTests(unittest.TestCase):
    def make(self, translate_status=200):
        state = {"tokens": 0, "status": translate_status}

        def handler(url, data, headers):
            if "auth" in url:
                state["tokens"] += 1
                return 200, {}, f"token{state['tokens']}"
            if state["status"] != 200:
                return state["status"], {}, ""
            texts = [d["Text"] for d in json.loads(data)]
            return 200, {}, json.dumps([{"translations": [{"text": "RU " + t}]} for t in texts])

        h, net = http(handler)
        now = [0.0]
        p = MicrosoftEdgeProvider(h, clock=lambda: now[0])
        return p, state, net, now

    def test_marked_experimental(self):
        p, *_ = self.make()
        self.assertTrue(p.experimental)

    def test_token_cached_then_refreshed_after_ttl(self):
        p, state, net, now = self.make()
        self.assertEqual(p.translate(["Hi"], LANG), ["RU Hi"])
        p.translate(["Again"], LANG)
        self.assertEqual(state["tokens"], 1)
        now[0] += 1000
        p.translate(["Later"], LANG)
        self.assertEqual(state["tokens"], 2)

    def test_expired_token_refreshed_once_then_error(self):
        p, state, net, now = self.make(translate_status=401)
        with self.assertRaises(AuthError):
            p.translate(["Hi"], LANG)
        self.assertEqual(state["tokens"], 2)  # одна повторная попытка, не бесконечно


class GoogleTests(unittest.TestCase):
    def test_single_request_for_all_blocks(self):
        def handler(url, data, headers):
            return 200, {}, json.dumps([[["Привет\n", "Hello\n"], ["Пока", "Bye"]]])

        h, net = http(handler)
        out = GoogleGtxProvider(h).translate(["Hello", "Bye"], LANG)
        self.assertEqual(out, ["Привет", "Пока"])
        self.assertEqual(len(net.requests), 1)
        self.assertTrue(GoogleGtxProvider(h).experimental)

    def test_falls_back_to_per_block_when_line_count_differs(self):
        replies = iter([
            json.dumps([[["склеено", "x"]]]),     # общий запрос: одна строка вместо двух
            json.dumps([[["Первый", "a"]]]),
            json.dumps([[["Второй", "b"]]]),
        ])
        h, net = http(lambda *a: (200, {}, next(replies)))
        out = GoogleGtxProvider(h).translate(["First", "Second"], LANG)
        self.assertEqual(out, ["Первый", "Второй"])
        self.assertEqual(len(net.requests), 3)


class FactoryTests(unittest.TestCase):
    def test_defaults_hide_experimental_and_use_gemini(self):
        m = build_manager(Settings(), env={})
        self.assertEqual(m.primary, "gemini")
        self.assertEqual({p.id for p in m.visible_providers()}, {"gemini", "claude"})

    def test_experimental_visible_when_allowed(self):
        s = Settings()
        s.allow_experimental = True
        m = build_manager(s, env={})
        self.assertEqual({p.id for p in m.visible_providers()},
                         {"gemini", "claude", "microsoft", "google"})

    def test_timeout_and_retries_applied_to_providers(self):
        s = Settings()
        s.timeout_s, s.retries = 7.0, 4
        m = build_manager(s, env={})
        self.assertEqual(m.providers["gemini"].http.timeout, 7.0)
        self.assertEqual(m.providers["gemini"].http.retries, 4)


if __name__ == "__main__":
    unittest.main()
