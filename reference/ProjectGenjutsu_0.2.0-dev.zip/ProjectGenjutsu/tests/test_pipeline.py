import unittest

from PIL import Image, ImageDraw

from genjutsu.capture.screen import Frame
from genjutsu.core.cancel import Cancelled
from genjutsu.core.pipeline import Pipeline, PipelineRequest
from genjutsu.ocr.types import OcrLine
from genjutsu.translation.base import LangPair


def img(color=0, rect=None):
    im = Image.new("RGB", (320, 180), (color, color, color))
    if rect:
        ImageDraw.Draw(im).rectangle(rect, fill=(255, 255, 255))
    return im


class Ctx:
    def __init__(self):
        self.cancelled = False

    def check(self):
        if self.cancelled:
            raise Cancelled()


class FakeCapture:
    def __init__(self, *frames):
        self.frames = list(frames)
        self.calls = 0

    def grab(self, region, dpr):
        self.calls += 1
        f = self.frames.pop(0) if len(self.frames) > 1 else self.frames[0]
        return f


class FakeOcr:
    def __init__(self, *results):
        self.results = list(results)
        self.calls = 0

    def recognize(self, image, lang):
        self.calls += 1
        r = self.results.pop(0) if len(self.results) > 1 else self.results[0]
        return r


class FakeTranslator:
    def __init__(self, fn=None, error=None):
        self.fn = fn or (lambda t: "RU:" + t)
        self.error = error
        self.calls = []

    def translate(self, texts, lang, cancel=None, glossary_version=""):
        self.calls.append(list(texts))
        if self.error:
            raise self.error
        return [self.fn(t) for t in texts]


class Clock:
    """Каждое обращение «тратит» заданное число секунд."""

    def __init__(self, step=0.0):
        self.t = 0.0
        self.step = step

    def __call__(self):
        self.t += self.step
        return self.t


LANG = LangPair("en-US", "ru", "Russian")


def req(force=False, dpr=1.0):
    return PipelineRequest(region=None, force=force, ocr_lang="en-US", lang=LANG, dpr=dpr)


A_LINES = [OcrLine(20, 20, 120, 40, "Where are you going?")]
B_LINES = [OcrLine(20, 20, 120, 40, "Hello again")]


def pipe(capture, ocr, translator, clock=None, verify_after=0.4):
    return Pipeline(capture, ocr, translator, verify_after_s=verify_after,
                    clock=clock or Clock())


class PipelineTests(unittest.TestCase):
    def test_basic_flow_scales_coordinates(self):
        cap = FakeCapture(Frame(img(0, (20, 20, 120, 40)), 100, 50))
        p = pipe(cap, FakeOcr(A_LINES), FakeTranslator())
        res = p.run(req(force=True, dpr=2.0), Ctx())
        self.assertEqual(res.items, [(60, 35, 110, 45, "RU:Where are you going?")])

    def test_unchanged_frame_is_skipped_but_force_bypasses(self):
        frame = Frame(img(0, (20, 20, 120, 40)), 0, 0)
        ocr, tr = FakeOcr(A_LINES), FakeTranslator()
        p = pipe(FakeCapture(frame), ocr, tr)
        self.assertIsNotNone(p.run(req(), Ctx()).items)
        res = p.run(req(), Ctx())
        self.assertEqual((res.items, res.skipped), (None, "unchanged"))
        self.assertEqual(ocr.calls, 1)
        self.assertIsNotNone(p.run(req(force=True), Ctx()).items)

    def test_same_text_on_changed_frame_does_not_retranslate(self):
        f1 = Frame(img(0, (20, 20, 120, 40)), 0, 0)
        f2 = Frame(img(60, (20, 20, 120, 40)), 0, 0)  # фон другой, текст тот же
        tr = FakeTranslator()
        p = pipe(FakeCapture(f1, f2), FakeOcr(A_LINES), tr)
        p.run(req(), Ctx())
        res = p.run(req(), Ctx())
        self.assertEqual((res.items, res.skipped), (None, "same_text"))
        self.assertEqual(len(tr.calls), 1)

    def test_reset_forgets_previous_text(self):
        frame = Frame(img(0, (20, 20, 120, 40)), 0, 0)
        tr = FakeTranslator()
        p = pipe(FakeCapture(frame), FakeOcr(A_LINES), tr)
        p.run(req(), Ctx())
        p.reset()
        self.assertIsNotNone(p.run(req(), Ctx()).items)
        self.assertEqual(len(tr.calls), 2)

    def test_screen_changed_during_translation_discards_result(self):
        """Появился текст A, пока он переводился, игрок перешёл к тексту B."""
        f_a = Frame(img(0, (20, 20, 120, 40)), 0, 0)
        f_b = Frame(img(0, (200, 100, 300, 160)), 0, 0)
        ocr = FakeOcr(A_LINES, B_LINES)
        p = pipe(FakeCapture(f_a, f_b), ocr, FakeTranslator(), clock=Clock(step=1.0))
        res = p.run(req(force=True), Ctx())
        self.assertIsNone(res.items)
        self.assertEqual(res.skipped, "screen_changed")
        self.assertTrue(res.retry_soon)

    def test_discarded_result_does_not_commit_state(self):
        f_a = Frame(img(0, (20, 20, 120, 40)), 0, 0)
        f_b = Frame(img(0, (200, 100, 300, 160)), 0, 0)
        tr = FakeTranslator()
        p = pipe(FakeCapture(f_a, f_b), FakeOcr(A_LINES, B_LINES, B_LINES, B_LINES), tr,
                 clock=Clock(step=1.0))
        p.run(req(force=True), Ctx())
        res = p.run(req(), Ctx())     # следующий тик: текст B должен быть переведён
        self.assertIsNotNone(res.items)
        self.assertEqual(tr.calls[-1], ["Hello again"])

    def test_slow_translation_but_screen_unchanged_is_shown(self):
        frame = Frame(img(0, (20, 20, 120, 40)), 0, 0)
        ocr = FakeOcr(A_LINES)
        p = pipe(FakeCapture(frame), ocr, FakeTranslator(), clock=Clock(step=1.0))
        res = p.run(req(force=True), Ctx())
        self.assertEqual(len(res.items), 1)
        self.assertEqual(ocr.calls, 1)  # дешёвая проверка областей без второго OCR

    def test_animated_background_same_text_is_still_shown(self):
        # «Буквы» занимают лишь часть рамки, остальное фон, который сильно изменился
        f1 = Frame(img(0, (50, 26, 70, 34)), 0, 0)
        f2 = Frame(img(200, (50, 26, 70, 34)), 0, 0)
        ocr = FakeOcr(A_LINES)
        p = pipe(FakeCapture(f1, f2), ocr, FakeTranslator(), clock=Clock(step=1.0))
        res = p.run(req(force=True), Ctx())
        self.assertEqual(len(res.items), 1)
        self.assertEqual(ocr.calls, 2)  # проверка через повторный OCR

    def test_translation_failure_is_retried_on_next_tick(self):
        """Раньше кадр помечался обработанным до перевода, и текст пропадал."""
        frame = Frame(img(0, (20, 20, 120, 40)), 0, 0)
        tr = FakeTranslator(error=RuntimeError("503"))
        p = pipe(FakeCapture(frame), FakeOcr(A_LINES), tr)
        with self.assertRaises(RuntimeError):
            p.run(req(), Ctx())
        tr.error = None
        res = p.run(req(), Ctx())
        self.assertIsNotNone(res.items)
        self.assertEqual(len(tr.calls), 2)

    def test_cancel_after_ocr_aborts_without_commit(self):
        frame = Frame(img(0, (20, 20, 120, 40)), 0, 0)
        ctx = Ctx()

        class CancellingOcr(FakeOcr):
            def recognize(self, image, lang):
                ctx.cancelled = True
                return super().recognize(image, lang)

        tr = FakeTranslator()
        p = pipe(FakeCapture(frame), CancellingOcr(A_LINES), tr)
        with self.assertRaises(Cancelled):
            p.run(req(), ctx)
        self.assertEqual(tr.calls, [])
        self.assertIsNotNone(p.run(req(), Ctx()).items)  # состояние не испорчено

    def test_result_already_in_target_language_is_not_drawn(self):
        frame = Frame(img(0, (20, 20, 120, 40)), 0, 0)
        p = pipe(FakeCapture(frame), FakeOcr(A_LINES), FakeTranslator(fn=lambda t: t))
        self.assertEqual(p.run(req(force=True), Ctx()).items, [])

    def test_no_text_returns_empty_items_to_clear_overlay(self):
        frame = Frame(img(0), 0, 0)
        tr = FakeTranslator()
        p = pipe(FakeCapture(frame), FakeOcr([]), tr)
        self.assertEqual(p.run(req(force=True), Ctx()).items, [])
        self.assertEqual(tr.calls, [])

    def test_timings_are_reported(self):
        frame = Frame(img(0, (20, 20, 120, 40)), 0, 0)
        res = pipe(FakeCapture(frame), FakeOcr(A_LINES), FakeTranslator()).run(req(True), Ctx())
        for key in ("capture_ms", "ocr_ms", "translate_ms", "total_ms"):
            self.assertIn(key, res.timings)


if __name__ == "__main__":
    unittest.main()
