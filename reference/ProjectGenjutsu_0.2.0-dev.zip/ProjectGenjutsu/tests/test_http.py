import socket
import unittest

from genjutsu.core.cancel import Cancelled
from genjutsu.translation.errors import (AuthError, BadResponse, NetworkError, NotFound,
                                         RateLimited, ServiceUnavailable)
from genjutsu.translation.http import HttpClient, parse_retry_after


class FakeOpener:
    """Отдаёт заранее заданные ответы по очереди."""

    def __init__(self, *responses):
        self.responses = list(responses)
        self.calls = 0

    def __call__(self, url, data, headers, timeout):
        self.calls += 1
        r = self.responses.pop(0) if len(self.responses) > 1 else self.responses[0]
        if isinstance(r, Exception):
            raise r
        return r


def client(opener, **kw):
    slept = []
    c = HttpClient(timeout=1, retries=kw.pop("retries", 2), opener=opener,
                   sleep=slept.append, rng=lambda: 0.0, **kw)
    c.slept = slept
    return c


class HttpTests(unittest.TestCase):
    def test_success(self):
        c = client(FakeOpener((200, {}, "ok")))
        self.assertEqual(c.request("u"), "ok")

    def test_503_retries_then_succeeds_with_exponential_backoff(self):
        op = FakeOpener((503, {}, ""), (503, {}, ""), (200, {}, "ok"))
        c = client(op)
        self.assertEqual(c.request("u"), "ok")
        self.assertEqual(op.calls, 3)
        self.assertAlmostEqual(sum(c.slept), 1.0 + 2.0, places=5)

    def test_503_gives_up_after_limited_retries(self):
        op = FakeOpener((503, {}, ""))
        c = client(op, retries=2)
        with self.assertRaises(ServiceUnavailable):
            c.request("u")
        self.assertEqual(op.calls, 3)  # одна попытка и два повтора, не бесконечно

    def test_retries_zero_means_single_attempt(self):
        op = FakeOpener((503, {}, ""))
        with self.assertRaises(ServiceUnavailable):
            client(op, retries=0).request("u")
        self.assertEqual(op.calls, 1)

    def test_429_short_retry_after_is_honored(self):
        op = FakeOpener((429, {"Retry-After": "2"}, ""), (200, {}, "ok"))
        c = client(op)
        self.assertEqual(c.request("u"), "ok")
        self.assertAlmostEqual(sum(c.slept), 2.0, places=5)

    def test_429_long_retry_after_is_not_slept_inline(self):
        op = FakeOpener((429, {"retry-after": "120"}, ""))
        c = client(op)
        with self.assertRaises(RateLimited) as cm:
            c.request("u")
        self.assertEqual(cm.exception.retry_after, 120.0)
        self.assertEqual(op.calls, 1)
        self.assertEqual(c.slept, [])

    def test_429_without_retry_after_raises_immediately(self):
        op = FakeOpener((429, {}, ""))
        with self.assertRaises(RateLimited):
            client(op).request("u")
        self.assertEqual(op.calls, 1)

    def test_404_not_retried(self):
        op = FakeOpener((404, {}, "model gone"))
        with self.assertRaises(NotFound):
            client(op).request("u")
        self.assertEqual(op.calls, 1)

    def test_auth_errors(self):
        for status, body in ((401, ""), (403, ""), (400, "API key not valid")):
            with self.assertRaises(AuthError):
                client(FakeOpener((status, {}, body))).request("u")

    def test_other_400_is_bad_response(self):
        with self.assertRaises(BadResponse):
            client(FakeOpener((400, {}, "bad json"))).request("u")

    def test_timeout_is_retried_then_reported(self):
        op = FakeOpener(NetworkError("The read operation timed out", timeout=True))
        c = client(op, retries=1)
        with self.assertRaises(NetworkError) as cm:
            c.request("u")
        self.assertTrue(cm.exception.timeout)
        self.assertEqual(op.calls, 2)

    def test_raw_socket_timeout_is_converted(self):
        op = FakeOpener(socket.timeout("timed out"))
        with self.assertRaises(NetworkError) as cm:
            client(op, retries=0).request("u")
        self.assertTrue(cm.exception.timeout)

    def test_cancel_before_request(self):
        class C:
            cancelled = True
        op = FakeOpener((200, {}, "ok"))
        with self.assertRaises(Cancelled):
            client(op).request("u", cancel=C())
        self.assertEqual(op.calls, 0)

    def test_cancel_during_backoff_stops_retries(self):
        class C:
            cancelled = False
        cancel = C()
        op = FakeOpener((503, {}, ""))
        c = client(op)
        c.sleep = lambda s: setattr(cancel, "cancelled", True)
        with self.assertRaises(Cancelled):
            c.request("u", cancel=cancel)
        self.assertEqual(op.calls, 1)

    def test_parse_retry_after(self):
        self.assertEqual(parse_retry_after("3"), 3.0)
        self.assertIsNone(parse_retry_after(None))
        self.assertIsNone(parse_retry_after("не число"))
        self.assertGreaterEqual(parse_retry_after("Wed, 21 Oct 2015 07:28:00 GMT"), 0.0)


if __name__ == "__main__":
    unittest.main()
