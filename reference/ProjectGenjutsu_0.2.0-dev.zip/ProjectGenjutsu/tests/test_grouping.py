import unittest

from genjutsu.ocr.types import OcrLine
from genjutsu.text_processing.grouping import block_signature, group_lines


def L(x1, y1, x2, y2, text):
    return OcrLine(x1, y1, x2, y2, text)


class GroupingTests(unittest.TestCase):
    def test_wrapped_sentence_becomes_one_block(self):
        blocks = group_lines([L(10, 100, 300, 120, "Where are you"),
                              L(10, 124, 200, 144, "going tonight?")])
        self.assertEqual(len(blocks), 1)
        self.assertEqual(blocks[0].text, "Where are you going tonight?")
        self.assertEqual((blocks[0].x1, blocks[0].y1, blocks[0].x2, blocks[0].y2),
                         (10, 100, 300, 144))

    def test_distant_lines_stay_separate(self):
        blocks = group_lines([L(10, 10, 100, 30, "Menu"), L(10, 400, 100, 420, "Quit game")])
        self.assertEqual([b.text for b in blocks], ["Menu", "Quit game"])

    def test_unsorted_input_is_read_top_to_bottom(self):
        blocks = group_lines([L(10, 124, 200, 144, "world"), L(10, 100, 300, 120, "Hello")])
        self.assertEqual(blocks[0].text, "Hello world")

    def test_cjk_joined_without_spaces(self):
        blocks = group_lines([L(10, 100, 300, 130, "今日は"), L(10, 134, 300, 164, "いい天気です")],
                             cjk=True)
        self.assertEqual(blocks[0].text, "今日はいい天気です")

    def test_symbol_only_blocks_are_dropped(self):
        self.assertEqual(group_lines([L(0, 0, 10, 10, "123 / 456"), L(0, 50, 10, 60, "...")]), [])

    def test_empty_input(self):
        self.assertEqual(group_lines([]), [])

    def test_side_by_side_columns_are_not_merged(self):
        blocks = group_lines([L(10, 100, 200, 120, "Attack"), L(600, 104, 800, 124, "Defend")])
        self.assertEqual(len(blocks), 2)

    def test_signature_changes_with_text_and_position(self):
        a = group_lines([L(10, 100, 300, 120, "Hello")])
        b = group_lines([L(10, 100, 300, 120, "Hello")])
        c = group_lines([L(10, 100, 300, 120, "Hello!")])
        d = group_lines([L(400, 300, 700, 320, "Hello")])
        self.assertEqual(block_signature(a), block_signature(b))
        self.assertNotEqual(block_signature(a), block_signature(c))
        self.assertNotEqual(block_signature(a), block_signature(d))


if __name__ == "__main__":
    unittest.main()
