import threading
import time
import unittest

from genjutsu.core.cancel import Cancelled
from genjutsu.core.jobs import LatestJobWorker


class Collector:
    def __init__(self):
        self.results = []
        self.errors = []
        self.busy = []
        self.done = threading.Event()

    def on_result(self, r):
        self.results.append(r)
        self.done.set()

    def on_error(self, e):
        self.errors.append(e)
        self.done.set()


def make():
    c = Collector()
    return LatestJobWorker(c.on_result, c.on_error, c.busy.append), c


def wait_until(cond, timeout=3.0):
    end = time.time() + timeout
    while time.time() < end:
        if cond():
            return True
        time.sleep(0.005)
    return False


class JobTests(unittest.TestCase):
    def test_runs_job_and_reports_busy(self):
        w, c = make()
        w.submit(lambda ctx: "A")
        self.assertTrue(c.done.wait(2))
        self.assertTrue(wait_until(lambda: c.busy[-1:] == [False]))
        self.assertEqual(c.results, ["A"])
        self.assertEqual(c.busy[0], True)
        w.stop()

    def test_stale_result_is_dropped(self):
        """Текст A переводится, пока на экране уже появился текст B."""
        w, c = make()
        started, release = threading.Event(), threading.Event()

        def slow_a(ctx):
            started.set()
            release.wait(2)
            return "перевод A"

        w.submit(slow_a)
        self.assertTrue(started.wait(2))
        t0 = time.time()
        w.submit(lambda ctx: "перевод B")  # вытесняет A
        self.assertTrue(wait_until(lambda: c.results == ["перевод B"], timeout=1.0))
        self.assertLess(time.time() - t0, 1.0)  # B не ждал зависший A
        release.set()
        time.sleep(0.1)
        self.assertEqual(c.results, ["перевод B"])  # A так и не показан
        w.stop()

    def test_context_reports_cancelled(self):
        w, c = make()
        seen = {}
        started, release = threading.Event(), threading.Event()

        def job(ctx):
            started.set()
            release.wait(2)
            seen["cancelled"] = ctx.cancelled
            ctx.check()
            return "x"

        w.submit(job)
        started.wait(2)
        w.cancel()
        release.set()
        self.assertTrue(wait_until(lambda: "cancelled" in seen))
        time.sleep(0.05)
        self.assertTrue(seen["cancelled"])
        self.assertEqual(c.results, [])
        self.assertEqual(c.errors, [])
        w.stop()

    def test_pending_slot_keeps_only_latest(self):
        w, c = make()
        started = [threading.Event(), threading.Event()]
        release = threading.Event()

        def blocker(i):
            def job(ctx):
                started[i].set()
                release.wait(2)
                return f"blocker{i}"
            return job

        w.submit(blocker(0))
        w.submit(blocker(1))
        self.assertTrue(started[0].wait(2) and started[1].wait(2))
        for name in ("p1", "p2", "p3"):
            w.submit(lambda ctx, n=name: n)
        release.set()
        self.assertTrue(wait_until(lambda: c.results == ["p3"]))
        time.sleep(0.05)
        self.assertEqual(c.results, ["p3"])  # очередь не копится, устаревшие отброшены
        w.stop()

    def test_thread_count_is_bounded(self):
        w, c = make()
        release = threading.Event()
        running = []
        lock = threading.Lock()
        peak = [0]

        def job(ctx):
            with lock:
                running.append(1)
                peak[0] = max(peak[0], len(running))
            release.wait(2)
            with lock:
                running.pop()
            return "x"

        for _ in range(10):
            w.submit(job)
            time.sleep(0.01)
        self.assertLessEqual(peak[0], 2)
        release.set()
        w.stop()

    def test_auto_submit_does_not_preempt_running_job(self):
        w, c = make()
        started, release = threading.Event(), threading.Event()

        def long_job(ctx):
            started.set()
            release.wait(2)
            return "long"

        w.submit(long_job, preempt=False)
        started.wait(2)
        accepted = w.submit(lambda ctx: "auto", preempt=False)
        self.assertFalse(accepted)
        release.set()
        self.assertTrue(wait_until(lambda: c.results == ["long"]))
        w.stop()

    def test_error_reported_only_for_current_job(self):
        w, c = make()

        def boom(ctx):
            raise RuntimeError("boom")

        w.submit(boom)
        self.assertTrue(c.done.wait(2))
        self.assertEqual(len(c.errors), 1)
        w.stop()

    def test_cancelled_exception_is_silent(self):
        w, c = make()

        def job(ctx):
            raise Cancelled()

        w.submit(job)
        self.assertTrue(wait_until(lambda: c.busy[-1:] == [False]))
        self.assertEqual((c.results, c.errors), ([], []))
        w.stop()

    def test_stop_is_prompt_and_rejects_new_jobs(self):
        w, c = make()
        w.submit(lambda ctx: "x")
        c.done.wait(2)
        t = time.time()
        w.stop()
        self.assertLess(time.time() - t, 1.0)
        self.assertFalse(w.submit(lambda ctx: "late"))

    def test_callback_exception_does_not_kill_worker(self):
        results = []
        w = LatestJobWorker(lambda r: (_ for _ in ()).throw(ValueError("ui")), print)
        w.on_result_backup = results
        w.submit(lambda ctx: 1)
        time.sleep(0.05)
        w._on_result = results.append
        w.submit(lambda ctx: 2)
        self.assertTrue(wait_until(lambda: results == [2]))
        w.stop()


if __name__ == "__main__":
    unittest.main()
