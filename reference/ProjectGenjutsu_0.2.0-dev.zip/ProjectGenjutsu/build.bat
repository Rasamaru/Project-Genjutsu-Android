@echo off
cd /d "%~dp0"

echo [1/3] Installing libraries...
python -m pip install PySide6 mss pillow winocr anthropic keyboard pyinstaller
if errorlevel 1 goto fail

echo [2/3] Building exe...
python -m PyInstaller --onefile --name ScreenTranslator --noupx --collect-all winocr --collect-submodules winrt run.py
if errorlevel 1 goto fail

echo [3/3] Done. File: dist\ScreenTranslator.exe
pause
exit /b 0

:fail
echo.
echo Build failed. Send the error text above.
pause
exit /b 1
