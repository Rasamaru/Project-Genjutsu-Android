# Project Genjutsu 0.2.0-dev (Этап 3: стабилизация ядра)

## Запуск из исходников
    pip install PySide6 mss pillow winocr anthropic keyboard
    python run.py

## Тесты (работают на любой ОС, нужен только Pillow)
    run_tests.bat
или `python -m unittest discover -s tests -t .`

## Сборка EXE
`build.bat`. Результат: `dist\ScreenTranslator.exe`. Окно консоли оставлено для отладки,
UPX выключен (он чаще вызывает ложные срабатывания антивирусов).
Подробный вывод времени каждого этапа: перед запуском `set GENJUTSU_DEBUG=1`.

## Структура
    genjutsu/
      app.py                 контроллер Qt и меню (только Windows)
      core/pipeline.py       захват -> изменения -> OCR -> группировка -> перевод -> проверка актуальности
      core/jobs.py           задачи «побеждает последняя», не более 2 потоков
      core/settings.py       несекретные настройки в %APPDATA%\ProjectGenjutsu\settings.json
      translation/           провайдеры, HTTP с повторами, менеджер, LRU-кэш
      text_processing/       склейка строк OCR в абзацы
      capture/, ocr/         захват (mss) и OCR (Windows), единственные места с Windows-API
      ui/                    оверлей, выбор области, плавающая кнопка (перенесены без изменений)
    tests/                   86 тестов логики без Windows

## Движки перевода
- Gemini: официальный API, нужен бесплатный ключ (переменная GEMINI_API_KEY). Модель: GEMINI_MODEL.
- Claude: необязательный, платный ключ (ANTHROPIC_API_KEY).
- Microsoft (токен Edge) и Google (gtx): НЕОФИЦИАЛЬНЫЕ, выключены по умолчанию.
  Включаются в меню: «Экспериментальные (неофициальные) движки».

## Что не проверено
Модули capture, ocr, ui и app.py проверены только на синтаксис: их можно проверить лишь в Windows.
